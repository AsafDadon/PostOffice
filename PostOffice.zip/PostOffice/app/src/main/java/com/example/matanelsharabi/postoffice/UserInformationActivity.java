package com.example.matanelsharabi.postoffice;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class UserInformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_information);

        EditText userName = (EditText) findViewById(R.id.editTextUserNameUserInformation);
        EditText password = (EditText) findViewById(R.id.editTextPasswordUserInformation);
        EditText firstName = (EditText) findViewById(R.id.editTextFirstNameUserInformation);
        EditText lastName = (EditText) findViewById(R.id.editTextLastNameUserInformation);
        EditText address = (EditText) findViewById(R.id.editTextAddressUserInformation);
        EditText email = (EditText) findViewById(R.id.editTextEmailUserInformation);

        SharedPreferences sp = getSharedPreferences("key", 0);
        String userNames = sp.getString("userName","");
        String passwords = sp.getString("password","");
        String firstNames = sp.getString("firstName","");
        String lastNames = sp.getString("lastName","");
        String addresss = sp.getString("address","");
        String emails = sp.getString("email","");

        userName.setText(userNames);
        password.setText(passwords);
        firstName.setText(firstNames);
        lastName.setText(lastNames);
        address.setText(addresss);
        email.setText(emails);
    }
}
