package com.example.matanelsharabi.postoffice;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        findViewById(R.id.nextbtnRegister).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText userName = (EditText) findViewById(R.id.editTextUserNameRegister);
                EditText password = (EditText) findViewById(R.id.editTextPasswordRegister);
                EditText firstName = (EditText) findViewById(R.id.editTextFirstNameRegister);
                EditText lastName = (EditText) findViewById(R.id.editTextLastNameRegister);
                EditText address = (EditText) findViewById(R.id.editTextAddressRegister);
                EditText email = (EditText) findViewById(R.id.editTextEmailRegister);

                SharedPreferences sp = getSharedPreferences("key", 0);
                SharedPreferences.Editor sedt = sp.edit();
                sedt.putString("userName", userName.getText().toString());
                sedt.putString("password", password.getText().toString());
                sedt.putString("firstName", firstName.getText().toString());
                sedt.putString("lastName", lastName.getText().toString());
                sedt.putString("address", address.getText().toString());
                sedt.putString("email", email.getText().toString());
                sedt.commit();

                Intent intent = new Intent(RegisterActivity.this, UploadImageRegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
